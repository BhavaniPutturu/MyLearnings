package com.salesforce.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.interactions.Actions;

public class Sample {

	public static void main(String[] args) throws InterruptedException {
		//ChromeOptions options = new ChromeOptions();
        //options.addArguments("--disable-notifications");
        //ChromeDriver driver = new ChromeDriver(options);
		EdgeOptions options = new EdgeOptions();
        options.addArguments("--disable-notifications");
		EdgeDriver driver = new EdgeDriver(options);
		JavascriptExecutor js = (JavascriptExecutor)driver;
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        driver.get("https://login.salesforce.com/");
        driver.findElement(By.id("username")).sendKeys("vidyar@testleaf.com");
        driver.findElement(By.id("password")).sendKeys("Sales@123");
        driver.findElement(By.id("Login")).click();
        driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
        driver.findElement(By.xpath("//button[text()='View All']")).click();
        Actions action = new Actions(driver);
        WebElement ele = driver.findElement(By.xpath("//p[text()='Individuals']"));
        action.scrollToElement(ele);
        action.build().perform();
        //action.moveToElement(ele);
        //action.build().perform();
        Thread.sleep(3000);
        js.executeScript("arguments[0].click();", ele);
        Thread.sleep(3000);
       /* js.executeScript("arguments[0].click();",
        		driver.findElement(By.xpath(
        	"//span[contains(text(),'Individuals')]/following::a")));
        WebElement eleNew = driver.findElement(By.xpath("//span[text()='New Individual']"));
        js.executeScript("arguments[0].click();", eleNew);
        
        driver.findElement(By.xpath("//span[text()='Last Name']/following::input")).sendKeys("Bhavani");
        
        driver.findElement(By.xpath("//button[@title='Save']")).click();*/

       js.executeScript("arguments[0].click();",
        		driver.findElement(By.xpath("//span[contains(text(),'Individuals')]")));
       driver.findElement(By.xpath("//input[@name='Individual-search-input']")).sendKeys("Bhavani", Keys.ENTER);
       	Thread.sleep(3000);
       driver.findElement(By.xpath("//table/tbody/tr/td[6]/span/div/a")).click();
       	driver.findElement(By.xpath("//a[@title='Delete']")).click();
       	driver.findElement(By.xpath("//span[text()='Delete']")).click();
       	driver.findElement(By.xpath("//input[@name='Individual-search-input']")).sendKeys("Bhavani", Keys.ENTER);
       	Thread.sleep(3000);
       	String text = driver.findElement(By.xpath("//span[@class='countSortedByFilteredBy']")).getText();
       	if(text.contains("0 items"))
       		System.out.println("deleted");
       	else
       		System.out.println("not deleted");
	}

}
